

var app = angular.module('MovieApp',['ngRoute', 'LocalStorageModule']);


/****** Config Views To App ******/

app.config(['$routeProvider', function($routeProvider){

  $routeProvider

    .when('/', {
      templateUrl: 'views/default.html',
      controller: 'MainContentController'
    })

    .when('/info/:id', {
      templateUrl : 'views/info.html',
      controller  : 'Info-New-Edit-Controller'
    })  

    .when('/edit/:id', {
      templateUrl : 'views/edit.html',
      controller  : 'Info-New-Edit-Controller'
    }) 

    .when('/new', {
      templateUrl : 'views/edit.html',
      controller  : 'Info-New-Edit-Controller'
    })

    .otherwise({
      redirectTo: '/'
    });
    
}]);


/****** Config Service To App ******/

app.factory('Movies', [function () {
	
    var service = {};

    service.entries = [
		{id:1, title:'Terminator', year:1984, duration:108, cast:'Arnold Schwarzenegger, Michael Biehn, Linda Hamilton, Paul Winfield, Lance Henriksen, Earl Boen. ', sinopsis: 'Over an apocalyptic battlefield in the year 2029, the ruins of the city of Los Angeles are dominated by robotic war machines, some like tanks, others are hovercrafts, a title card tells us that in the future, humans will wage a long war against an enemy known as the Machines. The "final battle" however, will not be fought in this future world, but in the past, specifically our present... tonight.'},
		{id:2, title:'Batman vs Superman: Dawn of Justice', year:2016, duration:151, cast:'Henry Cavill, Ben Affleck, Amy Adams, Jesse Eisenberg, Diane Lane, Laurence Fishburne, Jeremy Irons, Holly Hunter, Gal Gadot.', sinopsis: 'Superman (Henry Cavill ) has become the most controversial figure in the world. While many still believe that is an emblem of hope , another large number of people consider it a threat to humanity. For the influential Bruce Wayne (Ben Affleck ) , Superman is clearly a danger to society , their power is reckless and away from the hand of the government. Therefore, fear of the actions that can carry a superhero with a godlike powers , decides to put the mask and cape to put at bay superhero Metrópolis.Mientras that the public debate on the question of what is the hero who really need the Man of Steel and Batman, facing each other, are immersed in a race against each other.'},
		{id:3, title:'Mad Max: Fury Road', year:2015, duration:120, cast:'Tom Hardy, Charlize Theron.', sinopsis: 'The law and society no longer exists in this world consists of a desert wasteland , but there is blood, fire and death . However , there are two rebels who are able to restore the lost order , on the one hand is Max, who is still seeking its own peace after the death of his wife and son ; and on the other hand is Imperator Furious, a mysterious woman who tries to survive in this dangerous journey to his home.'},
	];

  //id generator
  service.getNewId = function() {

    if(service.newId) {

      service.newId++;

      return service.newId;

    }

    else {

      var entryMaxId = _.max(service.entries, function(entry){return entry.id});

      service.newId = entryMaxId.id + 1;

      return service.newId;

    }

  }

  //get an entry by id
  service.getById = function(id) {

    return _.find(service.entries, function(entry){return entry.id == id});

  }

  //update an entry
  service.save = function(entry) {

    var toUpdate = service.getById(entry.id);

    if(toUpdate) {

      _.extend(toUpdate, entry);

    }

    else {

      entry.id = service.getNewId();

      service.entries.push(entry);

    }  

  }

   //remove an entry
  service.remove = function(entry) {

    service.entries = _.reject(service.entries, function(element){

      return element.id == entry.id

    });

  }

  return service;    


}]);


/****** Config Controllers To App ******/

// General Controller
app.controller('MainContentController', ['$scope', 'Movies', 'localStorageService', function ($scope, Movies, localStorageService) { 

	$scope.movies = Movies.entries;
 
  $scope.remove = function(movies) {

    Movies.remove(movies);

  };

  // Watch the list of movie 
  $scope.$watch(function () { return Movies.entries; }, function (entries) {

    $scope.movies = entries;

  });

}]);

// New and Edit Content Controller
app.controller('Info-New-Edit-Controller', ['$scope', '$routeParams', '$location', 'Movies', 'localStorageService', function ($scope, $routeParams, $location, Movies, localStorageService) { 

  //Get info 
  if(!$routeParams.id){

    $scope.movie = { id:'', title:'', year:'', duration:'', cast:'', sinopsis:'' };

  }else{

    $scope.movie = _.clone(Movies.getById($routeParams.id));

  }

  // New and Edit save info
  $scope.save = function (){

    Movies.save($scope.movie);

    $location.path('/');

  }

}]);









