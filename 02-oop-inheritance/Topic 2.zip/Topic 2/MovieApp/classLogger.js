
//////Logger Class

export class Logger{ 

    constructor(){

        this.log = "Movie Info: "; 

    }
  
}

/* export Logger; */ 