
//////Social Object

export let social = {

    share: "friendName", // output: Share Iron Man with Mike Blossom

    like: "friendName"  // output: Like Iron Man with Mike Blossom

};

/* export social; */ 